bitstamp-price-ticker
==================

Google Chrome extension that shows [bitstamp.net](https://bitstamp.net) btc price/rate.

Get it from [Chrome Web Store](https://chrome.google.com/webstore/detail/bitstamp-btc-price/dobommehlbkjcjnbmhnnbcphncncjpid)
